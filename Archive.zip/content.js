/**
 * Instant Video Indexer — Content Script
 *
 * Injected into YouTube, Vimeo and Coursera pages.
 *
 * Responsibilities
 * ────────────────
 *  1. Detect the host platform & whether we are on a video page.
 *  2. Inject a "Scan Video" button near the player controls.
 *  3. Extract the transcript (captions) via the best available method.
 *  4. Forward the transcript to the service worker for AI indexing.
 *  5. Render a persistent, searchable sidebar with timestamped chapters.
 *  6. Sync the sidebar highlight to the playing video position.
 */
;(function () {
  'use strict'

  /* ================================================================
     CONSTANTS & STATE
     ================================================================ */

  const P = 'vid-indexer' // CSS / DOM id prefix
  const SIDEBAR_ID = `${P}-sidebar`
  const BUTTON_ID = `${P}-scan-btn`

  let platform = null   // 'youtube' | 'vimeo' | 'coursera' | null
  let sidebarOpen = false
  let transcript = null  // most recent extracted transcript
  let indexData = null   // most recent chapter index
  let syncRAF = null     // requestAnimationFrame handle

  /* ================================================================
     PLATFORM DETECTION
     ================================================================ */

  const Platform = {
    detect() {
      const h = location.hostname
      if (h.includes('youtube.com')) return 'youtube'
      if (h.includes('vimeo.com')) return 'vimeo'
      if (h.includes('coursera.org')) return 'coursera'
      return null
    },

    isVideoPage(p) {
      switch (p) {
        case 'youtube':
          return location.pathname === '/watch'
        case 'vimeo':
          return /^\/\d+/.test(location.pathname)
        case 'coursera':
          return location.pathname.includes('/lecture/')
        default:
          return false
      }
    },
  }

  /* ================================================================
     TRANSCRIPT EXTRACTORS
     ================================================================ */

  const Transcript = {
    /**
     * Dispatcher — pick the right extractor.
     * @param {string} p – platform name
     * @returns {Promise<Object>} structured transcript
     */
    async extract(p) {
      switch (p) {
        case 'youtube':
          return this._youtube()
        case 'vimeo':
          return this._vimeo()
        case 'coursera':
          return this._coursera()
        default:
          throw new Error(`Unsupported platform: ${p}`)
      }
    },

    /* ──────────── YouTube ──────────── */

    async _youtube() {
      const videoId = new URLSearchParams(location.search).get('v')
      if (!videoId) throw new Error('Cannot determine YouTube video ID.')

      // 1) Fetch the watch page HTML and pull captionTracks
      const segments = await this._ytFetchCaptions(videoId)

      if (!segments || segments.length === 0) {
        throw new Error(
          'No captions available for this YouTube video. ' +
          'Ensure the video has subtitles or auto-generated captions.'
        )
      }

      return this._buildTranscriptObject('youtube', videoId, segments)
    },

    /**
     * Fetch the raw watch-page HTML, locate the captionTracks JSON
     * blob, pick the best track, fetch its XML, and parse segments.
     */
    async _ytFetchCaptions(videoId) {
      /* --- grab the page source (same-origin fetch) --- */
      const pageRes = await fetch(
        `https://www.youtube.com/watch?v=${videoId}`,
        { credentials: 'same-origin' }
      )
      const html = await pageRes.text()

      /* --- locate "captionTracks":[…] --- */
      const marker = '"captionTracks":'
      const idx = html.indexOf(marker)
      if (idx === -1) return this._ytDOMFallback()

      const arrStart = html.indexOf('[', idx)
      if (arrStart === -1) return this._ytDOMFallback()

      let depth = 0,
        arrEnd = arrStart
      for (let i = arrStart; i < html.length; i++) {
        if (html[i] === '[') depth++
        if (html[i] === ']') {
          depth--
          if (depth === 0) {
            arrEnd = i + 1
            break
          }
        }
      }

      let tracks
      try {
        tracks = JSON.parse(html.substring(arrStart, arrEnd))
      } catch {
        return this._ytDOMFallback()
      }

      if (!tracks.length) return this._ytDOMFallback()

      // prefer English
      const track =
        tracks.find((t) => t.languageCode === 'en') || tracks[0]

      let captionUrl = track.baseUrl
      if (!captionUrl) return this._ytDOMFallback()

      // YouTube sometimes encodes & as \u0026 — already handled by
      // JSON.parse, but ensure it's a full URL
      if (captionUrl.startsWith('/')) {
        captionUrl = 'https://www.youtube.com' + captionUrl
      }

      /* --- fetch & parse the timed-text XML --- */
      const xmlRes = await fetch(captionUrl)
      const xmlText = await xmlRes.text()
      return this._parseTimedTextXML(xmlText)
    },

    /**
     * Parse YouTube's <transcript><text start="" dur="">…</text></transcript>
     */
    _parseTimedTextXML(xml) {
      const doc = new DOMParser().parseFromString(xml, 'text/xml')
      const nodes = doc.querySelectorAll('text')
      const segments = []

      nodes.forEach((n) => {
        const start = parseFloat(n.getAttribute('start') || '0')
        const dur = parseFloat(n.getAttribute('dur') || '0')
        // Decode HTML entities that YouTube embeds
        const text = n.textContent
          .replace(/&#39;/g, "'")
          .replace(/&quot;/g, '"')
          .replace(/&amp;/g, '&')
          .replace(/&lt;/g, '<')
          .replace(/&gt;/g, '>')
          .replace(/\n/g, ' ')
          .trim()

        if (text) segments.push({ start, duration: dur, end: start + dur, text })
      })

      return segments
    },

    /**
     * DOM fallback — scrape an already-open transcript panel.
     */
    _ytDOMFallback() {
      const items = document.querySelectorAll(
        'ytd-transcript-segment-renderer'
      )
      if (!items.length) return []

      const segments = []
      items.forEach((el) => {
        const timeEl = el.querySelector(
          '[class*="timestamp"], .segment-timestamp'
        )
        const textEl = el.querySelector(
          'yt-formatted-string, [class*="segment-text"]'
        )
        if (timeEl && textEl) {
          segments.push({
            start: this._hhmmssToSec(timeEl.textContent.trim()),
            duration: 0,
            end: 0,
            text: textEl.textContent.trim(),
          })
        }
      })
      return segments
    },

    /* ──────────── Vimeo ──────────── */

    async _vimeo() {
      const video = document.querySelector('video')
      if (!video) throw new Error('No <video> element found on this Vimeo page.')

      const segments = []
      const tracks = video.textTracks

      if (tracks && tracks.length) {
        const track = Array.from(tracks).find(
          (t) => t.kind === 'captions' || t.kind === 'subtitles'
        )
        if (track) {
          track.mode = 'hidden'
          // wait for cues to load
          await new Promise((r) => {
            if (track.cues?.length) return r()
            track.addEventListener('load', r, { once: true })
            setTimeout(r, 4000)
          })

          if (track.cues) {
            Array.from(track.cues).forEach((c) => {
              if (c.text.trim()) {
                segments.push({
                  start: c.startTime,
                  end: c.endTime,
                  duration: c.endTime - c.startTime,
                  text: c.text.trim(),
                })
              }
            })
          }
        }
      }

      if (!segments.length) {
        throw new Error(
          'No captions found for this Vimeo video. The owner may not have uploaded subtitles.'
        )
      }

      const videoId = location.pathname.replace(/^\//, '').split(/[/?]/)[0]
      return this._buildTranscriptObject('vimeo', videoId, segments)
    },

    /* ──────────── Coursera ──────────── */

    async _coursera() {
      const segments = []

      // Coursera renders phrases with data-start attributes
      const phrases = document.querySelectorAll(
        '[data-testid="transcript-phrase"], .rc-Phrase, ' +
        '[class*="phrases"] [role="button"], [class*="transcript"] [data-start]'
      )

      if (phrases.length) {
        phrases.forEach((el) => {
          const ms =
            el.getAttribute('data-start') || el.getAttribute('data-time')
          const start = ms ? parseFloat(ms) / 1000 : 0
          const text = el.textContent.trim()
          if (text) segments.push({ start, duration: 0, end: start, text })
        })
      } else {
        // fallback — video text tracks
        const video = document.querySelector('video')
        if (video?.textTracks?.length) {
          const track = video.textTracks[0]
          track.mode = 'hidden'
          await new Promise((r) => setTimeout(r, 2500))
          if (track.cues) {
            Array.from(track.cues).forEach((c) => {
              if (c.text.trim()) {
                segments.push({
                  start: c.startTime,
                  end: c.endTime,
                  duration: c.endTime - c.startTime,
                  text: c.text.trim(),
                })
              }
            })
          }
        }
      }

      if (!segments.length) {
        throw new Error(
          'No transcript found for this Coursera lecture. ' +
          'Make sure the transcript panel is available.'
        )
      }

      return this._buildTranscriptObject('coursera', location.pathname, segments)
    },

    /* ──────────── helpers ──────────── */

    _buildTranscriptObject(plt, id, segments) {
      return {
        platform: plt,
        videoId: id,
        title: document.title.replace(/ - YouTube$/, ''),
        segments,
        fullText: segments.map((s) => s.text).join(' '),
        extractedAt: new Date().toISOString(),
      }
    },

    _hhmmssToSec(str) {
      const parts = str.split(':').map(Number)
      if (parts.length === 3) return parts[0] * 3600 + parts[1] * 60 + parts[2]
      if (parts.length === 2) return parts[0] * 60 + parts[1]
      return Number(parts[0]) || 0
    },
  }

  /* ================================================================
     UI  — SCAN BUTTON
     ================================================================ */

  const Button = {
    inject(plt) {
      if (document.getElementById(BUTTON_ID)) return

      const btn = document.createElement('button')
      btn.id = BUTTON_ID
      btn.className = `${P}-scan-btn`
      btn.title = 'Generate AI-powered chapter index'
      btn.innerHTML = this._icon('scan') + '<span>Scan Video</span>'
      btn.addEventListener('click', onScanClick)

      const anchor = this._anchor(plt)
      if (anchor) {
        anchor.appendChild(btn)
      } else {
        btn.classList.add(`${P}-floating`)
        document.body.appendChild(btn)
      }
    },

    /** Platform-specific insertion point. */
    _anchor(plt) {
      const q = (s) => document.querySelector(s)
      switch (plt) {
        case 'youtube':
          return (
            q('#actions-inner #menu #top-level-buttons-computed') ||
            q('#top-level-buttons-computed') ||
            q('#above-the-fold #actions') ||
            q('#info-contents')
          )
        case 'vimeo':
          return q('[class*="controls"]') || q('.vp-controls')
        case 'coursera':
          return (
            q('[class*="control-bar"]') ||
            q('.rc-VideoControlsContainer')
          )
        default:
          return null
      }
    },

    setState(state) {
      const btn = document.getElementById(BUTTON_ID)
      if (!btn) return
      btn.disabled = state === 'loading'

      const map = {
        idle: { icon: 'scan', label: 'Scan Video' },
        loading: { icon: 'spinner', label: 'Scanning…' },
        done: { icon: 'check', label: 'View Index' },
        error: { icon: 'alert', label: 'Retry Scan' },
      }
      const s = map[state] || map.idle
      btn.innerHTML = this._icon(s.icon) + `<span>${s.label}</span>`
    },

    _icon(name) {
      const svgs = {
        scan: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>',
        spinner: `<div class="${P}-btn-spinner"></div>`,
        check: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"/></svg>',
        alert: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>',
      }
      return svgs[name] || ''
    },
  }

  /* ================================================================
     UI  — SIDEBAR
     ================================================================ */

  const Sidebar = {
    create() {
      if (document.getElementById(SIDEBAR_ID)) return

      const el = document.createElement('div')
      el.id = SIDEBAR_ID
      el.className = `${P}-sidebar`
      el.innerHTML = `
        <div class="${P}-sb-header">
          <h2><svg width="18" height="18" viewBox="0 0 24 24" fill="none"
            stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0
            00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline
            points="14 2 14 8 20 8"/></svg> Video Index</h2>
          <button id="${P}-close" class="${P}-sb-close" title="Close">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none"
              stroke="currentColor" stroke-width="2"><line x1="18" y1="6"
              x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
          </button>
        </div>

        <div class="${P}-sb-search">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none"
            stroke="currentColor" stroke-width="2"><circle cx="11" cy="11"
            r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
          <input id="${P}-search" type="text"
                 placeholder="Search chapters…" autocomplete="off"/>
        </div>

        <div id="${P}-summary" class="${P}-sb-summary"></div>
        <div id="${P}-chapters" class="${P}-sb-chapters"></div>

        <div class="${P}-sb-footer">
          <span>Instant Video Indexer</span>
          <button id="${P}-export" class="${P}-export-btn">Export ↓</button>
        </div>`

      document.body.appendChild(el)

      /* wire events */
      document.getElementById(`${P}-close`).addEventListener('click', () => this.toggle(false))
      document.getElementById(`${P}-search`).addEventListener('input', (e) => this.search(e.target.value))
      document.getElementById(`${P}-export`).addEventListener('click', () => this.exportMD())
    },

    toggle(show) {
      const el = document.getElementById(SIDEBAR_ID)
      if (!el) return
      sidebarOpen = show !== undefined ? show : !sidebarOpen
      el.classList.toggle(`${P}-sidebar-open`, sidebarOpen)
      document.body.classList.toggle(`${P}-body-shift`, sidebarOpen)
    },

    showLoading() {
      const s = document.getElementById(`${P}-summary`)
      if (s) s.innerHTML = `<div class="${P}-loader"><div class="${P}-spinner"></div><p>Extracting transcript &amp; generating index…</p></div>`
      const c = document.getElementById(`${P}-chapters`)
      if (c) c.innerHTML = ''
    },

    showError(msg) {
      const s = document.getElementById(`${P}-summary`)
      if (s) s.innerHTML = `<div class="${P}-error-card"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg><p>${escHTML(msg)}</p></div>`
    },

    /** Render the chapter index. */
    populate(data) {
      indexData = data

      /* summary */
      const sEl = document.getElementById(`${P}-summary`)
      if (sEl && data.summary) {
        sEl.innerHTML = `<div class="${P}-summary-card"><h3>Summary</h3><p>${escHTML(data.summary)}</p></div>`
      }

      /* chapters */
      const cEl = document.getElementById(`${P}-chapters`)
      if (!cEl || !data.chapters) return

      cEl.innerHTML = ''
      data.chapters.forEach((ch, i) => {
        const row = document.createElement('div')
        row.className = `${P}-chapter`
        row.dataset.idx = i
        row.dataset.ts = ch.timestamp
        row.dataset.search = `${ch.title} ${ch.description} ${(ch.keywords || []).join(' ')}`.toLowerCase()

        row.innerHTML = `
          <div class="${P}-ch-time" data-sec="${ch.timestamp}">${fmtTime(ch.timestamp)}</div>
          <div class="${P}-ch-body">
            <h4>${escHTML(ch.title)}</h4>
            ${ch.description ? `<p>${escHTML(ch.description)}</p>` : ''}
            ${ch.keywords?.length ? `<div class="${P}-tags">${ch.keywords.map((k) => `<span class="${P}-tag">${escHTML(k)}</span>`).join('')}</div>` : ''}
          </div>`

        row.addEventListener('click', () => seekTo(ch.timestamp))
        cEl.appendChild(row)
      })

      this._startSync()
    },

    search(q) {
      const norm = q.toLowerCase().trim()
      document.querySelectorAll(`.${P}-chapter`).forEach((el) => {
        el.style.display =
          !norm || el.dataset.search.includes(norm) ? '' : 'none'
      })
    },

    exportMD() {
      if (!indexData?.chapters) return
      let md = `# ${indexData.title || 'Video Index'}\n\n`
      if (indexData.summary) md += `## Summary\n${indexData.summary}\n\n`
      md += '## Chapters\n\n'
      indexData.chapters.forEach((ch) => {
        md += `- **[${fmtTime(ch.timestamp)}]** ${ch.title}\n`
        if (ch.description) md += `  ${ch.description}\n`
        md += '\n'
      })
      const blob = new Blob([md], { type: 'text/markdown' })
      const a = document.createElement('a')
      a.href = URL.createObjectURL(blob)
      a.download = `video-index-${Date.now()}.md`
      a.click()
      URL.revokeObjectURL(a.href)
    },

    /** Highlight the chapter matching the current playback position. */
    _startSync() {
      if (syncRAF) cancelAnimationFrame(syncRAF)

      const tick = () => {
        const video = document.querySelector('video')
        if (!video || !indexData?.chapters?.length) return

        const t = video.currentTime
        let activeIdx = 0
        for (let i = indexData.chapters.length - 1; i >= 0; i--) {
          if (t >= indexData.chapters[i].timestamp) {
            activeIdx = i
            break
          }
        }

        document.querySelectorAll(`.${P}-chapter`).forEach((el) => {
          const isActive = Number(el.dataset.idx) === activeIdx
          el.classList.toggle(`${P}-ch-active`, isActive)
          if (isActive && sidebarOpen) {
            el.scrollIntoView({ block: 'nearest', behavior: 'smooth' })
          }
        })

        syncRAF = requestAnimationFrame(tick)
      }

      syncRAF = requestAnimationFrame(tick)
    },
  }

  /* ================================================================
     CORE HANDLERS
     ================================================================ */

  async function onScanClick() {
    /* already indexed? just toggle sidebar */
    if (indexData) {
      Sidebar.toggle(true)
      return
    }

    /* check for API key */
    const settings = await getSettings()
    if (!settings.apiKey) {
      Sidebar.create()
      Sidebar.toggle(true)
      Sidebar.showError(
        'API key not set. Click the <strong>extension icon</strong> in the toolbar to configure your API key.'
      )
      return
    }

    Button.setState('loading')
    Sidebar.create()
    Sidebar.toggle(true)
    Sidebar.showLoading()

    try {
      /* 1 — extract transcript */
      transcript = await Transcript.extract(platform)

      if (
        !transcript ||
        !transcript.segments ||
        transcript.segments.length === 0
      ) {
        throw new Error(
          'Transcript is undefined or empty. The video may lack captions.'
        )
      }

      /* 2 — send to AI via background service worker */
      const result = await new Promise((resolve, reject) => {
        chrome.runtime.sendMessage(
          {
            type: 'SUMMARIZE_TRANSCRIPT',
            payload: {
              transcript,
              apiKey: settings.apiKey,
              apiEndpoint: settings.apiEndpoint,
              model: settings.model,
              videoTitle: transcript.title,
            },
          },
          (resp) => {
            if (chrome.runtime.lastError) {
              return reject(new Error(chrome.runtime.lastError.message))
            }
            resp?.success
              ? resolve(resp.data)
              : reject(new Error(resp?.error || 'AI summarisation failed'))
          }
        )
      })

      /* 3 — render */
      Sidebar.populate(result)
      Button.setState('done')

      /* 4 — cache */
      const key = `idx_${transcript.videoId}`
      chrome.storage.local.set({ [key]: result })
    } catch (err) {
      console.error('[VidIndexer]', err)
      Sidebar.showError(err.message)
      Button.setState('error')
      indexData = null
    }
  }

  /* ================================================================
     SETTINGS HELPER
     ================================================================ */

  function getSettings() {
    return new Promise((resolve) => {
      chrome.storage.sync.get(
        {
          apiKey: '',
          apiEndpoint: 'https://api.openai.com/v1/chat/completions',
          model: 'gpt-4o',
          language: 'en',
        },
        resolve
      )
    })
  }

  /* ================================================================
     SEEK
     ================================================================ */

  function seekTo(sec) {
    const v = document.querySelector('video')
    if (v) {
      v.currentTime = sec
      v.play().catch(() => {})
    }
  }

  /* ================================================================
     INITIALISATION
     ================================================================ */

  function init() {
    platform = Platform.detect()
    if (!platform || !Platform.isVideoPage(platform)) return

    console.log(`[VidIndexer] Platform: ${platform}`)

    waitFor(playerSelector(platform), () => Button.inject(platform))
  }

  function playerSelector(p) {
    switch (p) {
      case 'youtube':
        return '#above-the-fold, #info-contents, ytd-watch-metadata'
      case 'vimeo':
        return '.vp-controls, [class*="player_controls"], .player'
      case 'coursera':
        return '[class*="control-bar"], .rc-VideoControlsContainer, video'
      default:
        return 'video'
    }
  }

  function waitFor(selector, cb, timeout = 15000) {
    if (document.querySelector(selector)) return cb()

    const obs = new MutationObserver(() => {
      if (document.querySelector(selector)) {
        obs.disconnect()
        cb()
      }
    })
    obs.observe(document.body, { childList: true, subtree: true })
    setTimeout(() => {
      obs.disconnect()
      cb() // try anyway (floating fallback)
    }, timeout)
  }

  /* ================================================================
     SPA NAVIGATION (YouTube uses History API)
     ================================================================ */

  if (location.hostname.includes('youtube.com')) {
    document.addEventListener('yt-navigate-finish', () => {
      const old = document.getElementById(BUTTON_ID)
      if (old) old.remove()
      transcript = null
      indexData = null
      if (syncRAF) cancelAnimationFrame(syncRAF)
      setTimeout(init, 800)
    })
  }

  window.addEventListener('popstate', () => setTimeout(init, 600))

  /* ================================================================
     MESSAGES FROM POPUP / BACKGROUND
     ================================================================ */

  chrome.runtime.onMessage.addListener((msg, _s, respond) => {
    if (msg.type === 'TRIGGER_SCAN') {
      onScanClick()
      respond({ ok: true })
    }
    if (msg.type === 'GET_STATUS') {
      respond({
        platform,
        isVideoPage: Platform.isVideoPage(platform),
        hasIndex: !!indexData,
      })
    }
    return true
  })

  /* ================================================================
     UTILITIES
     ================================================================ */

  function fmtTime(sec) {
    const h = Math.floor(sec / 3600)
    const m = Math.floor((sec % 3600) / 60)
    const s = Math.floor(sec % 60)
    const pad = (n) => String(n).padStart(2, '0')
    return h ? `${pad(h)}:${pad(m)}:${pad(s)}` : `${pad(m)}:${pad(s)}`
  }

  function escHTML(str) {
    const d = document.createElement('div')
    d.textContent = str
    return d.innerHTML
  }

  /* ================================================================
     BOOT
     ================================================================ */

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init)
  } else {
    init()
  }
})()