/**
 * Instant Video Indexer — Background Service Worker
 */

/* ──────────────────────── message router ──────────────────────── */

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message.type === 'SUMMARIZE_TRANSCRIPT') {
    // SECURITY CHECK: Verify key exists before calling AI
    chrome.storage.sync.get(['apiKey'], (result) => {
      if (!result.apiKey || result.apiKey.trim() === "") {
        sendResponse({ 
          success: false, 
          error: "Please set your API key in the extension settings to begin indexing." 
        });
      } else {
        handleSummarisation(message.payload)
          .then((data) => sendResponse({ success: true, data }))
          .catch((err) => sendResponse({ success: false, error: err.message }));
      }
    });
    return true; // keep channel open for async
  }

  if (message.type === 'TEST_API_KEY') {
    testApiKey(message.apiKey, message.apiEndpoint)
      .then(() => sendResponse({ success: true }))
      .catch((err) => sendResponse({ success: false, error: err.message }));
    return true;
  }
});

/* ──────────────────── summarisation handler ───────────────────── */

async function handleSummarisation(payload) {
  const { transcript, apiKey, apiEndpoint, model } = payload;

  const prompt = `Create a structured chapter index with timestamps for this video transcript. 
  Format: [00:00] Title. Transcript: ${JSON.stringify(transcript)}`;

  const res = await fetch(apiEndpoint, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model: model || 'gpt-4o-mini',
      messages: [
        { role: 'system', content: 'You are an expert video editor. Create a timestamped index.' },
        { role: 'user', content: prompt }
      ],
      temperature: 0.2,
    }),
  });

  if (!res.ok) {
    const errorBody = await res.json().catch(() => ({}));
    throw new Error(errorBody?.error?.message || `API Error: ${res.status}`);
  }

  return await res.json();
}

/* ──────────────────── API Key Test ───────────────────── */

async function testApiKey(apiKey, apiEndpoint) {
  const res = await fetch(apiEndpoint, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model: 'gpt-4o-mini',
      messages: [{ role: 'user', content: 'Connection test. Reply with OK.' }],
      max_tokens: 5,
    }),
  });

  if (res.status === 401) throw new Error('Invalid API key provided.');
  if (!res.ok) throw new Error(`Connection failed: ${res.status}`);
}

/* ────────────────── lifecycle / badge ─────────────────────────── */

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.sync.set({
    apiKey: '',
    apiEndpoint: 'https://api.openai.com/v1/chat/completions',
    model: 'gpt-4o-mini', // Aligned with popup.js
  });
});

// Performance optimization: Update badge only on supported video URLs
chrome.tabs.onUpdated.addListener((tabId, info, tab) => {
  if (info.status !== 'complete' || !tab.url) return;
  const isSupported = tab.url.includes('youtube.com/watch') || 
                     tab.url.includes('vimeo.com') || 
                     tab.url.includes('coursera.org');
  
  if (isSupported) {
    chrome.action.setBadgeText({ tabId, text: 'ON' });
    chrome.action.setBadgeBackgroundColor({ tabId, color: '#6366f1' });
  } else {
    chrome.action.setBadgeText({ tabId, text: '' });
  }
});