;(function () {
  'use strict'

  const $ = (id) => document.getElementById(id)

  const DEFAULTS = {
    apiKey: '',
    apiEndpoint: 'https://api.openai.com/v1/chat/completions',
    model: 'gpt-4o-mini',
  }

  // Load saved settings
  chrome.storage.sync.get(DEFAULTS, (s) => {
    if ($('apiKey')) $('apiKey').value = s.apiKey;
    if ($('apiEndpoint')) $('apiEndpoint').value = s.apiEndpoint || DEFAULTS.apiEndpoint;
    if ($('model')) $('model').value = s.model || DEFAULTS.model;
  })

  // Check Subscription Status (Displays banner to encourage upgrades)
  chrome.identity.getProfileUserInfo(async (userInfo) => {
    const banner = $('proBanner');
    if (banner) {
      // Show banner by default for the first version
      banner.style.display = 'block';
    }
  });

  // Handle Upgrade Button with your Stripe link
  const upgradeBtn = $('upgradeBtn');
  if (upgradeBtn) {
    upgradeBtn.addEventListener('click', () => {
      window.open('https://buy.stripe.com/7sI8xidI7erRgs85kk', '_blank');
    });
  }

  // Save Settings
  const saveBtn = $('saveBtn');
  if (saveBtn) {
    saveBtn.addEventListener('click', () => {
      const apiKey = $('apiKey').value.trim();
      const apiEndpoint = $('apiEndpoint').value.trim() || DEFAULTS.apiEndpoint;
      const model = $('model').value;

      if (!apiKey) return showStatus('Please enter an API key.', false);

      chrome.storage.sync.set({ apiKey, apiEndpoint, model }, () => {
        showStatus('Settings saved ✓', true);
      });
    });
  }

  // Test API Key
  const testBtn = $('testBtn');
  if (testBtn) {
    testBtn.addEventListener('click', () => {
      const apiKey = $('apiKey').value.trim();
      const apiEndpoint = $('apiEndpoint').value.trim() || DEFAULTS.apiEndpoint;

      if (!apiKey) return showStatus('Enter an API key first.', false);

      testBtn.disabled = true;
      testBtn.textContent = 'Testing...';

      chrome.runtime.sendMessage(
        { type: 'TEST_API_KEY', apiKey, apiEndpoint },
        (resp) => {
          testBtn.disabled = false;
          testBtn.textContent = 'Test Key';
          if (resp?.success) {
            showStatus('API key is valid ✓', true);
          } else {
            showStatus(resp?.error || 'Validation failed.', false);
          }
        }
      );
    });
  }

  function showStatus(msg, ok) {
    const el = $('status');
    if (!el) return;
    el.textContent = msg;
    el.className = 'status ' + (ok ? 'ok' : 'err');
    setTimeout(() => { el.textContent = ''; }, 3000);
  }
})()